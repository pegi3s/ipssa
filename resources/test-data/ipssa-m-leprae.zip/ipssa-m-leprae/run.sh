#!/bin/bash

# Edit the PROJECT_DIR variable
PROJECT_DIR=/path/to/ipssa-m-leprae-project


# Adjust the COMPI_NUM_TASKS to an appropiate value
COMPI_NUM_TASKS=8


PIPELINE_WORKING_DIR=${PROJECT_DIR}/pipeline_working_dir
INPUT_DIR=${PROJECT_DIR}/input
PARAMS_DIR=${PROJECT_DIR}

docker run -v /tmp:/tmp -v /var/run/docker.sock:/var/run/docker.sock -v ${PIPELINE_WORKING_DIR}:/working_dir -v ${INPUT_DIR}:/input -v ${PARAMS_DIR}:/params --rm pegi3s/ipssa -o --logs /working_dir/logs --num-tasks ${COMPI_NUM_TASKS} -pa /params/ipssa-project.params -- --host_working_dir ${PIPELINE_WORKING_DIR}
